import 'package:flutter/material.dart';
import 'package:school_flutter/page/student/studentData.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:fluttertoast/fluttertoast.dart';


class Student extends StatefulWidget {

  @override
  _StudentState createState() => _StudentState();
}

class _StudentState extends State<Student> {
  Future<List<studentData>> future;



  @override
  Widget build(BuildContext context) {
    future = studentData().studentDataApi();

    return FutureBuilder<List<studentData>>(
        future: future,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data.length,
              itemBuilder: (context, index) {
                return Card(
                  child: ListTile(
                    title: Text(
                      '${snapshot.data[index].firstName}' + ' ' + '${snapshot.data[index].firstName}',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    onTap: () {
                      Navigator.pushNamed(
                          context,
                          '/studentProfile',
                          arguments: {
                            'firstName': snapshot.data[index].firstName,
                            'lastName': snapshot.data[index].lastName,
                            'roll': snapshot.data[index].roll,
                            'email': snapshot.data[index].email,
                            'phone': snapshot.data[index].phone,
                          }
                      );
                    },
                  ),
                );
              },
            );

          } else {
            return SpinKitFadingCircle(
              color: Colors.black,
              size: 70,
            );

          }

        });

  }
}


