
import 'package:flutter/material.dart';


class AddStudent extends StatefulWidget {

  @override
  _AddStudent createState() => _AddStudent();

}
class _AddStudent extends State<AddStudent> {
  @override
  Widget build(BuildContext context) {
    TextEditingController firstNameCont = TextEditingController();
    TextEditingController lastNameCont = TextEditingController();
    TextEditingController rollCont = TextEditingController();
    TextEditingController emailCont = TextEditingController();
    TextEditingController phoneCont = TextEditingController();


    return MaterialApp(
      theme: ThemeData(
        primaryColor: Colors.teal,
      ),

      home: Scaffold(

        appBar: AppBar(
          title: Text('Add New Student',
            style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold
            ),
          ),

        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              TextField(
                controller: firstNameCont,
                keyboardType: TextInputType.name,
                style: TextStyle(fontSize: 20),
                decoration: InputDecoration(
                  helperText: '',
                  helperStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15
                  ),
                  hintText: 'First Name',
                ),
              ),

              SizedBox(height: 10,),

              TextField(
                controller: lastNameCont,
                keyboardType: TextInputType.name,
                style: TextStyle(fontSize: 20),
                decoration: InputDecoration(
                  helperText: '',
                  helperStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15
                  ),
                  hintText: 'Last Name',
                ),
              ),


              SizedBox(height: 10,),

              TextField(
                controller: rollCont,
                style: TextStyle(fontSize: 20),
                decoration: InputDecoration(
                  helperText: '',
                  helperStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15
                  ),
                  hintText: 'Roll',
                ),
              ),

              SizedBox(height: 10,),

              TextField(
                controller: emailCont,
                keyboardType: TextInputType.emailAddress,
                style: TextStyle(fontSize: 20),
                decoration: InputDecoration(
                  helperText: '',
                  helperStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15
                  ),
                  hintText: 'Email',
                ),
              ),

              SizedBox(height: 10,),


              TextField(
                controller: phoneCont,

                keyboardType: TextInputType.phone,
                style: TextStyle(fontSize: 20),
                decoration: InputDecoration(
                  helperText: '',
                  helperStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15
                  ),
                  hintText: 'Email Address',
                ),
              ),


              SizedBox(height: 40,),
              Align(alignment: Alignment.center,
                child: RaisedButton(
                    child: Text('Submit'),
                    padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50)
                    ),
                    color: Colors.teal,
                    onPressed: () {}),
              )
            ],
          ),
        ),
      ),
    );

  }


}
