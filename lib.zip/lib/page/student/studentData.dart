import 'dart:convert';
import 'package:http/http.dart';

class studentData {
  final int id;
  final String firstName;
  final String lastName;
  final String roll;
  final String email;
  final String phone;

  String url = 'http://10.0.2.2:8000/api/all_student';

  studentData({
    this.id,
    this.firstName,
    this.lastName,
    this.roll,
    this.email,
    this.phone });

  factory studentData.fromJson(Map<String, dynamic> json) {
    return studentData(
        id: json['id'],
        firstName: json['first_name'],
        lastName: json['last_name'],
        roll: json['roll'],
        email: json['email'],
        phone: json['phone']
    );
  }

  Future<List<studentData>> studentDataApi() async {
    Response response = await get(url);

    if (response.statusCode == 200) {
      Iterable iterable = jsonDecode(response.body);
      return iterable.map((e) => studentData.fromJson(e)).toList();

    } else {
      return null;
    }

  }
}