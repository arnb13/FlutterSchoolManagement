//import 'dart:js';
import 'package:flutter/material.dart';


class StudentProfile extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    Map map = ModalRoute.of(context).settings.arguments;
    String firstNameData = map['firstName'];
    String lastNameData = map['lastName'];
    String rollData = map['roll'];
    String emailData = map['email'];
    String phoneData = map['phone'];

    return MaterialApp(
      theme: ThemeData(
          primaryColor: Colors.teal,
      ),

      home: Scaffold(

        appBar: AppBar(
          title: Text('Student Profile',
            style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold
            ),
          ),

        ),
        body: Container(
          padding: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('First Name: ',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(firstNameData,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 25,
                  //fontWeight: FontWeight.bold,
                ),
              ),
              Divider(
                color: Colors.black12,
                thickness: 3,
                height: 20,
              ),

              Text('Last Name: ',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(lastNameData,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 25,
                  //fontWeight: FontWeight.bold,
                ),
              ),
              Divider(
                color: Colors.black12,
                thickness: 3,
                height: 20,
              ),


              Text('Roll: ',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(rollData,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 25,
                  //fontWeight: FontWeight.bold,
                ),
              ),
              Divider(
                color: Colors.black12,
                thickness: 3,
                height: 20,
              ),


              Text('Email: ',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(emailData,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 25,
                  //fontWeight: FontWeight.bold,
                ),
              ),
              Divider(
                color: Colors.black12,
                thickness: 3,
                height: 20,
              ),


              Text('Phone: ',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(phoneData,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 25,
                  //fontWeight: FontWeight.bold,
                ),
              ),

            ],
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          label: Text('Edit Profile', style: TextStyle(color: Colors.black),),
          icon: Icon(Icons.edit_rounded, color: Colors.black,),
          backgroundColor: Colors.teal,
          onPressed: () {
            Navigator.pushNamed(context, '/editProfile', arguments: {
              'firstName': firstNameData,
              'lastName': lastNameData,
              'roll': rollData,
              'email': emailData,
              'phone': phoneData,
            }
            );
          },

        ),

      ),
    );
  }
  
}
