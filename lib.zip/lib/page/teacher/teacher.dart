import 'package:flutter/material.dart';
import 'package:school_flutter/navigation_drawer/navigationDrawer.dart';


class Teacher extends StatefulWidget {
  @override
  _TeacherState createState() => _TeacherState();
}

class _TeacherState extends State<Teacher> {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text('Teacher')],
    );

  }
}